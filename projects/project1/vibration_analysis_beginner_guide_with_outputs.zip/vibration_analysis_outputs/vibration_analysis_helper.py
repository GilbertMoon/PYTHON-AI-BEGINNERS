
from pathlib import Path
import pandas as pd
import numpy as np

def read_meta(path, n_lines=52, encoding="latin1"):
    lines = []
    with open(path, "r", encoding=encoding, errors="replace") as f:
        for _ in range(n_lines):
            line = f.readline()
            if not line:
                break
            lines.append(line.rstrip("\r\n").split("\t"))
    return lines

def find_data_start(path, encoding="latin1"):
    with open(path, "r", encoding=encoding, errors="replace") as f:
        for i, line in enumerate(f):
            parts = line.rstrip("\r\n").split("\t")
            try:
                float(parts[0])
                float(parts[1])
                return i
            except Exception:
                continue
    raise ValueError(f"숫자 데이터 시작 행을 찾지 못했습니다: {path}")

def parse_meta_channels(path):
    lines = read_meta(path)
    n_groups = max((len(x) for x in lines), default=0) // 4
    rows = []
    for g in range(n_groups):
        d = {"group": g, "time_col": g * 4, "value_col": g * 4 + 1}
        for parts in lines:
            key_idx = g * 4
            val_idx = g * 4 + 1
            key = parts[key_idx].strip() if key_idx < len(parts) else ""
            val = parts[val_idx].strip() if val_idx < len(parts) else ""
            if key and key not in d:
                d[key] = val
        rows.append(d)
    return pd.DataFrame(rows)

def read_channel(path, group, data_start=None, encoding="latin1"):
    if data_start is None:
        data_start = find_data_start(path, encoding=encoding)

    usecols = [group * 4, group * 4 + 1]
    df = pd.read_csv(
        path,
        sep="\t",
        header=None,
        skiprows=data_start,
        usecols=usecols,
        names=["time", "value"],
        encoding=encoding,
        engine="c",
        na_values=[""],
        on_bad_lines="skip",
    )
    df["time"] = pd.to_numeric(df["time"], errors="coerce")
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    return df.dropna().reset_index(drop=True)

def find_channel_group(meta, keyword):
    mask = meta.astype(str).apply(
        lambda row: row.str.contains(keyword, case=False, regex=False, na=False).any(),
        axis=1,
    )
    hits = meta[mask]
    if len(hits) == 0:
        raise ValueError(f"채널을 찾지 못했습니다: {keyword}")
    return int(hits.iloc[0]["group"])

def read_z_channel(path):
    meta = parse_meta_channels(path)

    # +Z가 적힌 채널을 자동 검색합니다.
    mask = meta.astype(str).apply(
        lambda row: row.str.contains("+Z", regex=False, na=False).any(),
        axis=1,
    )
    hits = meta[mask]

    # 진동 채널이 여러 개 잡힐 경우 Vibration 채널 우선
    if len(hits) > 1 and "Channelgroup" in hits.columns:
        vib = hits[hits["Channelgroup"].astype(str).str.contains("Vibration", case=False, na=False)]
        if len(vib) > 0:
            hits = vib

    if len(hits) == 0:
        raise ValueError(f"Z+ 채널을 찾지 못했습니다: {path}")

    group = int(hits.iloc[0]["group"])
    return read_channel(path, group), hits.iloc[0].to_dict(), meta

def extract_features(df, threshold=5.0):
    t = df["time"].to_numpy()
    y = df["value"].to_numpy()
    ay = np.abs(y)

    duration = float(t[-1] - t[0]) if len(t) > 1 else 0.0
    dt = float(np.median(np.diff(t))) if len(t) > 1 else np.nan
    over = ay >= threshold

    # 기준값 이상으로 새로 진입한 횟수
    event_count = int(np.sum(over & np.r_[True, ~over[:-1]])) if len(over) else 0

    # 기준값을 넘은 만큼의 면적. 단발성 튐보다 지속적 이상을 잡는 데 유용합니다.
    excess = np.maximum(ay - threshold, 0)
    area = float(np.trapezoid(excess, t)) if len(t) > 1 else 0.0

    duration_over = float(over.sum() * dt) if len(t) > 1 else 0.0

    return {
        "n_samples": int(len(y)),
        "duration_sec": duration,
        "sample_rate_hz": float(1 / dt) if dt and dt > 0 else np.nan,
        "mean": float(np.mean(y)),
        "std": float(np.std(y)),
        "rms": float(np.sqrt(np.mean(y * y))),
        "max": float(np.max(y)),
        "min": float(np.min(y)),
        "max_abs": float(np.max(ay)),
        "p95_abs": float(np.percentile(ay, 95)),
        "p99_abs": float(np.percentile(ay, 99)),
        f"count_abs_ge_{threshold}": int(over.sum()),
        f"duration_abs_ge_{threshold}_sec": duration_over,
        f"event_count_abs_ge_{threshold}": event_count,
        f"area_over_{threshold}": area,
    }

def read_xls_clean(path):
    # .XLS 구형 엑셀 파일은 xlrd 엔진이 필요합니다.
    # 설치가 안 되어 있으면: pip install xlrd
    df = pd.read_excel(path, sheet_name=0, engine="xlrd")

    time_col = df.columns[0]
    df[time_col] = pd.to_numeric(df[time_col], errors="coerce")
    for col in df.columns[1:]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=[time_col]).reset_index(drop=True)
    return df.rename(columns={time_col: "time"})

def estimate_offset_by_xcorr(t_txt, y_txt, t_xls, y_xls, dt=0.005, max_lag=3.0):
    """
    공통 CAN 신호를 이용해 TXT와 XLS 시간 오프셋을 추정합니다.

    반환값 offset_sec의 의미:
    - XLS 시간에 offset_sec를 더하면 TXT 시간축과 더 잘 맞습니다.
    - 예: offset_sec = 1.4 이면 xls_time_aligned = xls_time + 1.4
    """
    t_txt = np.asarray(t_txt, dtype=float)
    y_txt = np.asarray(y_txt, dtype=float)
    t_xls = np.asarray(t_xls, dtype=float)
    y_xls = np.asarray(y_xls, dtype=float)

    # 각 파일의 시작 시간을 0으로 맞춘 뒤 상관계수를 비교합니다.
    t_txt0 = t_txt - t_txt[0]
    t_xls0 = t_xls - t_xls[0]

    start = max(t_txt0.min(), t_xls0.min())
    end = min(t_txt0.max(), t_xls0.max())
    grid = np.arange(start, end, dt)

    a = np.interp(grid, t_txt0, y_txt)
    b = np.interp(grid, t_xls0, y_xls)

    a = (a - np.mean(a)) / (np.std(a) + 1e-9)
    b = (b - np.mean(b)) / (np.std(b) + 1e-9)

    max_shift = int(max_lag / dt)
    lags = np.arange(-max_shift, max_shift + 1)
    corrs = []

    for lag in lags:
        if lag < 0:
            aa = a[-lag:]
            bb = b[: len(aa)]
        elif lag > 0:
            aa = a[:-lag]
            bb = b[lag:]
        else:
            aa = a
            bb = b

        corrs.append(float(np.mean(aa * bb)))

    corrs = np.array(corrs)
    best_lag = lags[int(np.argmax(corrs))] * dt

    # 위 계산에서 best_lag가 음수이면 TXT 이벤트가 XLS보다 늦게 나타난다는 뜻입니다.
    # 따라서 XLS 시간에 더해 줄 보정값은 -best_lag입니다.
    offset_sec = -float(best_lag)
    return offset_sec, float(corrs.max())
